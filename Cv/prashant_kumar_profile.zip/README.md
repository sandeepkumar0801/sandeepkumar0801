[PLACEHOLDER]
The full README.md was generated in chat. Replace this placeholder with the full content from the conversation.
